package com.test.fabrik.testFabrick;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestFabrickApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestFabrickApplication.class, args);
	}

}
