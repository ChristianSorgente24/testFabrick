package com.test.fabrik.testFabrick.controller;

import static org.junit.jupiter.api.Assertions.*;

class ControllerTest {

}