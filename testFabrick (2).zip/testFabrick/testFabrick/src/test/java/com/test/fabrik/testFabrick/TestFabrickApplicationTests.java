package com.test.fabrik.testFabrick;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestFabrickApplicationTests {

	@Test
	void contextLoads() {
	}

}
